package com.example.denmarkinventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    private UserDatabaseHelper dbHelper;

    public ItemDAO(Context context) {
        dbHelper = new UserDatabaseHelper(context);
    }

    // Add a new item to the database
    public void addItem(String itemName, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserDatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(UserDatabaseHelper.COLUMN_ITEM_QUANTITY, quantity);

        db.insert(UserDatabaseHelper.TABLE_ITEMS, null, values);
        db.close();
    }

    // Get all items from the database
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(UserDatabaseHelper.TABLE_ITEMS, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(UserDatabaseHelper.COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(UserDatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(UserDatabaseHelper.COLUMN_ITEM_QUANTITY));
                itemList.add(new Item(id, name, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return itemList;
    }

    // Update an item's quantity
    public void updateItem(int itemId, int newQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserDatabaseHelper.COLUMN_ITEM_QUANTITY, newQuantity);

        db.update(UserDatabaseHelper.TABLE_ITEMS, values, UserDatabaseHelper.COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
    }

    // Delete an item from the database
    public void deleteItem(int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(UserDatabaseHelper.TABLE_ITEMS, UserDatabaseHelper.COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
    }
}