package com.example.denmarkinventoryappui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<Item> itemList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemDelete(int itemId);
        void onItemUpdate(int itemId, int newQuantity);
    }

    public InventoryAdapter(List<Item> itemList, OnItemClickListener listener) {
        this.itemList = itemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        Item currentItem = itemList.get(position);

        holder.itemName.setText(currentItem.getName());
        holder.itemQuantity.setText(String.valueOf(currentItem.getQuantity()));

        // Handle delete button
        holder.deleteButton.setOnClickListener(v -> listener.onItemDelete(currentItem.getId()));

        // Handle update button (simulating update of quantity to +1 for demo)
        holder.updateButton.setOnClickListener(v -> {
            int newQuantity = currentItem.getQuantity() + 1;
            listener.onItemUpdate(currentItem.getId(), newQuantity);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity;
        Button deleteButton, updateButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            updateButton = itemView.findViewById(R.id.updateButton);
        }
    }
}