package com.example.denmarkinventoryappui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity implements InventoryAdapter.OnItemClickListener {

    // Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    // Flag to track if SMS permission has been granted
    private boolean isSmsPermissionGranted = false;

    // Data Access Object for interacting with item data
    private ItemDAO itemDAO;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        // Check and request SMS permission if needed
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            isSmsPermissionGranted = true;
        } else {
            requestSmsPermission();
        }

        // Initialize ItemDAO for managing inventory data
        itemDAO = new ItemDAO(this);

        // Set up RecyclerView for displaying items in a grid layout
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));  // 2 columns in the grid

        // Retrieve all items and display them in the RecyclerView
        List<Item> itemList = itemDAO.getAllItems();
        adapter = new InventoryAdapter(itemList, this);
        recyclerView.setAdapter(adapter);

        // Add new items to the inventory when the "Add" button is clicked
        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(v -> {
            EditText itemNameField = findViewById(R.id.editTextItemName);
            EditText itemQuantityField = findViewById(R.id.editTextItemQuantity);

            String itemName = itemNameField.getText().toString();
            String quantityText = itemQuantityField.getText().toString();

            // Ensure both item name and quantity are provided
            if (!itemName.isEmpty() && !quantityText.isEmpty()) {
                int itemQuantity = Integer.parseInt(quantityText);

                // Add the new item to the database
                itemDAO.addItem(itemName, itemQuantity);

                // Send an SMS notification if the item quantity is low
                if (itemQuantity < 5) {
                    sendSmsNotification("Low inventory alert for item: " + itemName);
                }

                // Refresh the list to include the new item
                List<Item> updatedItemList = itemDAO.getAllItems();
                adapter = new InventoryAdapter(updatedItemList, this);
                recyclerView.setAdapter(adapter);

                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter both item name and quantity", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Request SMS permission from the user
    private void requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            // Explain why SMS permission is needed
            Toast.makeText(this, "SMS permission is required to send notifications", Toast.LENGTH_LONG).show();
        }
        // Request the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Handle the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                isSmsPermissionGranted = true;
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                isSmsPermissionGranted = false;
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send an SMS notification if permission has been granted
    private void sendSmsNotification(String message) {
        if (isSmsPermissionGranted) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String phoneNumber = "1234567890";  // Set the recipient's phone number
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted. Cannot send message.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle deleting an item from the inventory
    @Override
    public void onItemDelete(int itemId) {
        // Delete the item from the database
        itemDAO.deleteItem(itemId);

        // Refresh the item list
        List<Item> updatedItemList = itemDAO.getAllItems();
        adapter = new InventoryAdapter(updatedItemList, this);
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setAdapter(adapter);

        Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
    }

    // Handle updating an item's quantity in the inventory
    @Override
    public void onItemUpdate(int itemId, int newQuantity) {
        // Update the item quantity in the database
        itemDAO.updateItem(itemId, newQuantity);

        // Send an SMS notification if the new quantity is low
        if (newQuantity < 5) {
            Item updatedItem = itemDAO.getAllItems().stream().filter(item -> item.getId() == itemId).findFirst().orElse(null);
            if (updatedItem != null) {
                sendSmsNotification("Low inventory alert for item: " + updatedItem.getName());
            }
        }

        // Refresh the item list
        List<Item> updatedItemList = itemDAO.getAllItems();
        adapter = new InventoryAdapter(updatedItemList, this);
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setAdapter(adapter);

        Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
    }
}